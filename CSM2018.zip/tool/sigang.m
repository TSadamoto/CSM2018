%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given 
% x = [xr(1), xi(1)]
%     [xr(2), xi(2)]
%       :      :
%     [xr(T), xi(T)]
%
% Return
% angle of x. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = sigang(x,varargin)

if(size(x,2) ~= 2)
  error('number of columns must be 2');
end

ret = atan2(x(:,2), x(:,1));
ret = unwrap(ret);
