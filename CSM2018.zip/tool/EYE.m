function ret = EYE(n,I)

tmp = eye(n);

ret = tmp(:,I);