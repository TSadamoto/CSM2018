% ********************************************
% Choose what model is used for retrofit controller design
% We use a full-dimensional model of the system to be controlled. 
% ********************************************
function [A, B, G, P, Pdag, varargout] = make_lowdim(Ain, Bin, nhat)
global meth

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use full-dimensional model
%%%%%%%%%%%%%%%%%%%%%%%%%%
A = Ain;
B = Bin;
G = 0;
P = eye(nhat);
Pdag = eye(nhat);
varargout{1} = []; 