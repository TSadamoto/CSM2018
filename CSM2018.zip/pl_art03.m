%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot for article (no/all retrofit/global/ all retrfoti+global)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ya = [-0.1, 0.1]; ta = [0, 25]; pa = [-300 200];
figure;
subplot(4,2,1);
plot(res_ori.t, res_ori.ome,'b-','linewidth',1); hold on; 
grid on; ylabel('ome[Hz]'); xlim([ta(1) ta(2)]); ylim([ya(1) ya(2)]);
subplot(4,2,2);
plot(res_ori.t, mpc.baseMVA*real(res_ori.P(:, j)) ,'b-','linewidth',1); hold on; 
plot(res_ori.t, mpc.baseMVA*imag(res_ori.P(:, j)),'r-','linewidth',1); hold on; 
grid on; ylabel('Power[MW]'); xlim([ta(1) ta(2)]); ylim([pa(1) pa(2)]);

subplot(4,2,3);
plot(res{lp}.t, res{lp}.ome,'b-','linewidth',1); hold on; 
grid on; ylabel('ome[Hz]'); xlim([ta(1) ta(2)]); ylim([ya(1) ya(2)]);
subplot(4,2,4);
plot(res{lp}.t, mpc.baseMVA*real(res{lp}.P(:, j)) ,'b-','linewidth',1); hold on; 
plot(res{lp}.t, mpc.baseMVA*imag(res{lp}.P(:, j)),'r-','linewidth',1); hold on; 
grid on; ylabel('Power[MW]'); xlim([ta(1) ta(2)]); ylim([pa(1) pa(2)]);

subplot(4,2,5);
plot(res_glo.t, res_glo.ome,'b-','linewidth',1); hold on; 
grid on; ylabel('ome[Hz]'); xlim([ta(1) ta(2)]); ylim([ya(1) ya(2)]);
subplot(4,2,6);
plot(res_glo.t, mpc.baseMVA*real(res_glo.P(:, j)) ,'b-','linewidth',1); hold on; 
plot(res_glo.t, mpc.baseMVA*imag(res_glo.P(:, j)),'r-','linewidth',1); hold on; 
grid on; ylabel('Power[MW]'); xlim([ta(1) ta(2)]); ylim([pa(1) pa(2)]);

subplot(4,2,7);
plot(res_gl.t, res_gl.ome,'b-','linewidth',1); hold on; 
grid on; ylabel('ome[Hz]'); xlim([ta(1) ta(2)]); ylim([ya(1) ya(2)]);
subplot(4,2,8);
plot(res_gl.t, mpc.baseMVA*real(res_gl.P(:, j)) ,'b-','linewidth',1); hold on; 
plot(res_gl.t, mpc.baseMVA*imag(res_gl.P(:, j)),'r-','linewidth',1); hold on; 
grid on; ylabel('Power[MW]'); xlim([ta(1) ta(2)]); ylim([pa(1) pa(2)]);