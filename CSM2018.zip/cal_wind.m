% ***********************************
% Calculate wind
%    NOTE!! cal_sg must be called before calling cal_wind
% ***********************************

% ===== calculate some of wind system state =====
wl = (1/(2*pi))*(omega0/2)*x(:, out.w_wl);
wr = (1/(2*pi))*(omega0/2)*x(:, out.w_wr);
thT = 180/pi*x(:, out.w_thT);
is = x(:, out.w_is);
ir = x(:, out.w_ir);
ig = x(:, out.w_ig);
vdc = x(:, out.w_vdc)*diag(wind_con(:,20));


mR = cell(1,NW);
mG = cell(1,NW);
Powg = cell(1,NW);
for j=1:NW
  mR{j} = zeros(length(t),2);
  mG{j} = zeros(length(t),2);
  us{j} = zeros(length(t),win{j}.m);
  Powg{j} = zeros(length(t),2);
  for k=1:length(t)
    xwin = x(k, win{j}.si)'; 
    Powg{j}(k,:) = win{j}.powG(EW(k,2*j-1:2*j)', xwin); 
    if(flag(j) == 1)
      us{j}(k, :) = compw{j}.u(x(k,compw{j}.si)', xwin)';
    else
      us{j}(k, :) = zeros(win{j}.m,1);
    end
    
    if RSC_flag == 1
      mG{j}(k,:) = win{j}.mG(xwin(8:13), EW(k,2*j-1:2*j)', xwin(18), vdc_s{j}, Q_s{j}, us{j}(1:2))';
      mR{j}(k,:) = win{j}.mR(xwin(14:15), xwin(4:5), win{j}.ir_ref(xwin(16:17), xwin(2), EW(k,2*j-1:2*j)', init_EW(2*j-1:2*j), wr_s{j}, ir_s{j}(2)), xwin(18), us{j}(3:4))';
    else
      mG{j}(k,:) = win{j}.mG(xwin(8:13), EW(k,2*j-1:2*j)', xwin(16), vdc_s{j}, Q_s{j}, us{j}(1:2))';
      mR{j}(k,:) = win{j}.mR(xwin(14:15), xwin(4:5), win{j}.ir_ref(ir_s{j}, xwin(2), EW(k,2*j-1:2*j)', init_EW(2*j-1:2*j), wr_s{j}, ir_s{j}(2)), xwin(16), us{j}(3:4))';	
    end
  end
end

if sto_flag == 1
  vb = x(:, out.vb)*diag(wind_con(:,20)); 
  idcP = x(:, out.idcP); 
  Sdc = Ss + us{j}(:, 5); 
end