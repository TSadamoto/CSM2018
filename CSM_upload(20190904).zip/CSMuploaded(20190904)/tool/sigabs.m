%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given 
% x = [xr(1), xi(1)]
%     [xr(2), xi(2)]
%       :      :
%     [xr(T), xi(T)]
%
% Return
% absolute value of x. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = sigabs(x,varargin)

if(size(x,2) ~= 2)
  error('number of columns must be 2');
end

ret = sqrt((x(:,1).*x(:,1)) + (x(:,2).*x(:,2)));
