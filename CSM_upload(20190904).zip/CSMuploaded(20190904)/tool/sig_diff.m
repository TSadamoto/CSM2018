%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Given 
% x = [x1, x2,...,xN], k
%
% Return
% ret = [x1-xk, x2-xk, ..., xN-xk]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret = sig_diff(x,k)

[T,N] = size(x); 

tmp = x - x(:,k)*ones(1,N);

if k == 1
  ret = tmp(:,2:end);
elseif k == N
  ret = tmp(:,1:end-1);
else
  ret = [tmp(:,1:k-1), tmp(:,k+1:end)];
end
