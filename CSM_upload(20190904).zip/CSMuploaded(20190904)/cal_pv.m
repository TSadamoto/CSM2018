% ***********************************
% Calculate pv state
% ***********************************
% ===== calculate some of wind system state =====
ig_pv = x(:, out.pv_ig);
vdc_pv = x(:, out.pv_vdc)*diag(pv_con(:,2));
  
for j=1:NP
  mGpv{j} = zeros(length(t),2);
  upv{j} = zeros(length(t),pv{j}.m);
  for k=1:length(t)
    xp = x(k, pv{j}.si)';

    if flag_pv(j) == -1
      % ****** without retrofit  *******
      u = zeros(pv{j}.m,1);
    elseif flag_pv(j) == 1
      % ****** with retrofit  *******
      xhat = x(k, compw_pv{j}.si)'; 
      u = compw_pv{j}.u(xhat, xp);
    end
    upv{j}(k,:) = u'; 
    mGpv{j}(k,:) = pv{j}.mG(xp(1:6), xp(7), EP(k,2*j-1:2*j)', P_spv{j}, Q_spv{j}, u);
  end
end