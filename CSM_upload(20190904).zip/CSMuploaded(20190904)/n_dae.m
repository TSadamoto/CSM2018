%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function is used to calculate the dimension of the closed-loop system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ret=n_dae(fg_W, fg_P)
global compw compw_pv NW NP

ret = 0;
if(NW>0); ret = ret + (fg_W==1).*t_cell(compw, 'n'); end
if(NP>0); ret = ret + (fg_P==1).*t_cell(compw_pv, 'n'); end
ret;
