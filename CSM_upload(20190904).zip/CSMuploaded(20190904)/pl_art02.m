%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot for article (no controllers / single retrofit / two retrofit)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
col = [0 0 1; 1 0 0; 0 0.8 0; 1 1 0; 0.5 0.5 0.1]; 
figure;
subplot(1,2,1);
plot(res_sr.t, res_sr.ome,'-','Color', [0 0.9 0],'linewidth',1); hold on; 
plot(res_ori.t, res_ori.ome,'r--','linewidth',1); hold on; 
plot(res{lp}.t, res{lp}.ome,'b-','linewidth',1); hold on; 
grid on; ylabel('ome[Hz]'); xlim([-1 50]); 

subplot(1,2,2);
plot(res_sr.t, res_sr.uw{1},'r--','linewidth',1); hold on; 
plot(res{lp}.t, res{lp}.upv{1},'b-','linewidth',1); hold on; 
grid on; ylabel('input'); xlim([res_sr.t(1) res_sr.t(end)]); xlim([-0.5 2.5]);